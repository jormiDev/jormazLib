/*
 *	jormazLib.cpp
 */

#include "jormazLib.h"

/*
 *	Ficheros CPP incluidos
 */
 
#include "jormiDepura.cpp"
#include "jormiPulsador.cpp"
#include "jormiLed.cpp"
#include "jormi5Direcciones.cpp"
#include "jormiL293D.cpp"
